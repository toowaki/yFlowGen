// f
void func_f( void )
{
	int a = 0;
	
	if( enu == OK )
	{
		switch( processN )
		{
			case 1:
				a = 1;
				break;
			
			default:
				break;
		}
	}
	else
	{
		a = 2;
	}
	
	return;
}

// g
void func_g( void )
{
	int a = 0;
	
	if( enu == OK )
	{
		switch( processN )
		{
			case 1:
				a = 1;
				break;
			default:
				break;
		}
		
		sub();
	}
	else
	{
		a = 2;
	}
	
	return;
}