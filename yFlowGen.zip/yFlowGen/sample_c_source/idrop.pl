 # cvt.pl. Convert helloworld.pl into a camel shape.
    use Acme::EyeDrops qw(sightly);
    print sightly( { SourceFile  => 'yFlowGen.pl',
                     Regex       => 1 } );