int TEST( void )
{
	int ret = ERROR;

	if( ret = FUNC_A( IsMain() ) )
	{
	}
	else
	{
		if( IsMain() == true )
		{
			if( ret = FUNC_B( VAL1 ) )
			{
			}
			else
			{
				ret = OK;
			}
		}
		else
		{
			if( ret = FUNC_B( VAL2 ) )
			{
			}
			else
			{
				ret = OK;
			}
		}
	}
	return ret;
}