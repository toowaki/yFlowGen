#include <stdio.h>

//==============================
/ return
//==============================

int return_test1(void) {
	if (1) {
		/* ここで関数return_test1()は終わります */
		return 300;
	}

	/* ここは通りません */
	printf("this is a()\n");

	return 10;
}

//==============================
/ exit
//==============================

int exit_test1(void)
{
	int i;

	i = atexit(bye); // 正常終了時に呼び出される関数を設定
	if (i != 0) {
		fprintf(stderr, "cannot set exit function\n");
		exit(EXIT_FAILURE);
	}
	printf("good morning\n");
	exit(EXIT_SUCCESS);
}

int exit_test2(void)
{
    int i;

    i = atexit(bye); // 正常終了時に呼び出される関数を設定
    if (i != 0) {
        fprintf(stderr, "cannot set exit function\n");
        _exit(EXIT_FAILURE);
    }

    printf("good morning\n");
    _exit(EXIT_SUCCESS);
}


