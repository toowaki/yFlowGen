sub()
{
if (count>5) count=8;
else pos=3; }