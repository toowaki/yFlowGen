 int sub7(){
            for (a=1;a<1; a++)
            {
                int in_subj = ( ( A ||
                                (B || 
                                 C ) )) ? 1 : 0;

              if( 1 )
              {
              	a=1;
              }
            }
}