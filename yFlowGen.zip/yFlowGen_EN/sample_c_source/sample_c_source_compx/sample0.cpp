int sample_fnc(int i_val1) {
	/* if */
	if (i_val1 == 0) cout << "YES\n";
	else
		cout << "NO\n";
	// for
	int i, j;
	for (i = 1; i <= 3; i++){
		for (j = 1; j <= 3; j++){
		  printf("sample coden");
		}
	}
}

