class Color
{
public:
    UInt08 r;
    UInt08 g;
    UInt08 b;
    
    Color()
    {
        r = g = b = 0;
    }

    Color(UInt08 n)
    {
        r = g = b = n;
    }

    Color(UInt08 r0, UInt08 g0, UInt08 b0)
    {
        r = r0;
        g = g0;
        b = b0;
    }
};