// f
void func_f( void )
{
	int a = 0;
	
	if( enu == OK )
	{
		switch( processN )
		{
			case 1:
				a = 1;
				break;
			
			default:
				break;
		}
	}
	else
	{
		a = 2;
	}
	
	return;
}

// g
void func_g( void )
{
	int a = 0;
	
	if( enu == OK )
	{
		switch( processN )
		{
			case 1:
				a = 1;
				break;
			default:
				break;
		}
		
		sub();
	}
	else
	{
		a = 2;
	}
	
	return;
}

int func_if(void){
	int a; int b; int c;
	b = 1;
	c = 1;
	for(i=0;i<10;i++){
		if(b=0) a=1; else if(1) a=1; else a=2;
	}
	if (a) sub01(); else sub2();
	return a;
}