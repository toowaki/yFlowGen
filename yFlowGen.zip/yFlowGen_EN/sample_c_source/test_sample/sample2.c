#include <iostream>
using namespace std;

template <class Type> 
void sub1( Type &a, Type &b )
{
if(w<=0){
if(x<=0){
if(y<=0){
	if(z<1){
		Type temp = a;
		printf("}}�̏����p");
		a = b;
		b = temp;}}
}}}

sub2()
{
if(y<=0){
	if(z<1){
		Type temp = a;
		printf("}}�̏����p");
		a = b;
		b = temp;}}

if (count>5) count=8;
else pos=3; }

struct_test()
{	
if (x>5) //test1
	count=8;
else if (y>2) 
	count=5;	
else pos=3;

if (x>5) count=8;//test2
else if (y>2) count=5;	
else pos=3; }