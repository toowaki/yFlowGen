int TEST( void )
{
	int ret = ERROR;

	if( ret = FUNC_A( IsMain() ) )
	{
	}
	else
	{
		if( IsMain() == true )
		{
			if( ret = FUNC_B( VAL1 ) )
			{
			}
			else
			{
				ret = OK;
			}
		}
		else
		{
			if( ret = FUNC_B( VAL2 ) )
			{
			}
			else
			{
				ret = OK;
			}
		}
	}
	return ret;
}

int TEST2( void )
{
	int ret = NG;

	if( ret = FUNC_A() )
	{
	}
	else if( ret = FUNC_B() )
	{
	}
	#ifndef COMPILE_A
		else if( ret = FUNC_C1() )
		{
		}
	#else
		else if( ret = FUNC_C2() )
		{
		}
	#endif
	else
	{
		ret = OK;
	}

	for(i=0;i<10;i++){
		b=1;
	}
	return ret;
}

int TEST3( void )
{
	int ret = NG;

	if( ret = FUNC_A() )
	{
	}
	else if( ret = FUNC_B() )
	{
	}
	else if( ret = FUNC_C() )
	{
	}
	else
	{
		ret = OK;
	}

	for(i=0;i<10;i++){
		b=1;
	}
	return ret;
}