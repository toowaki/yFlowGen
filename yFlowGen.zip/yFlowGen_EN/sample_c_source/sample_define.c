#include <stdio.h>
#include "Main.h"
#define _TARGET_C
#define  DUMMY_LOCK  (1)
//#ifdef DUMMY_LOCK
static LOSW_REG_FUNC_T m_Test02 = { NULL, Test02 };
 
int main(void){
	// Your code here!
	Test01();
	Test02();
}
 
void Test01(void)
{
	printf("test01\r\n");
}
 
_EXT void Test02(void)
{
			  do{
							while(1) {
								printf("test02\r\n");
							}
			  }while(1)
}
 
static BOOL_T Test03(E_CMD_SEQ *p_seq)
{
			  UINT32_T len;
			  INT32_T lRet;
			  BOOL_T bRet = BOOL_FALSE;
			  common_frame_t			 msg;
			 
			  lRet = LOSW_MsgRecieve(DUMMY_MSG, (void **)&msg);
			  if(lRet > 0){
							switch(msg.id){
										  case CMD_1:
														if(CMD_SEQ_1 == *p_seq){
														}else{
															a=1;
														}
														break;
										  case CMD_2:
#ifdef DUMMY_LOCK
														if(true == dummy1){
																	  debug_print("[dummp] Send Lock Through.");
														}else if(CMD_TEST == *p_seq){
#else
													if(CMD_TEST == *p_seq){
														A = 1;
														B = 1;
#endif
																	  sta_flg = BOOL_FALSE;
														}else{
																	  debug_print_dw1("[dump] Send Error:", (UINT32_T)*p_seq);
														}
														break;
										  default:
														debug_print_dw1("dummySnd ID Error!:", (UINT32_T)msg.id);
														break;
							}
			  }else if(E_TMOUT == lRet){
							dummy = CMD_WAIT;
							bRet = BOOL_TRUE;
			  }else{
							bRet = BOOL_FALSE;
			  }
			 
			  return bRet;
}

void Test04(){
// A
// B
// C
#ifdef AAA
	#ifdef BBB
		x=b;
	#else
		x=c;
	#endif
#else
	x=a;
#endif


#ifdef CCC
	x=0;
#endif
	aaa=1;
}
	

void sub_def_samples(){
	#ifndef MACRO_H
	#define MACRO_H

	#define SWAP(type, a, b) \
	        do {type tmp = a; a = b; b = tmp;} while (0)

	#define XOR_SWAP(a, b) \
	        do {a ^= b; b ^= a; a ^= b;} while (0)


	#define MAX(a, b) ((a) > (b) ? (a) : (b))
}
