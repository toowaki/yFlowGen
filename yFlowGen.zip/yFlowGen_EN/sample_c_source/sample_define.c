#include <stdio.h>
#include "Main.h"
#define _TARGET_C
#define  DUMMY_LOCK  (1)
//#ifdef DUMMY_LOCK
static LOSW_REG_FUNC_T m_Test02 = { NULL, Test02 };

#define NUM 1
 
int main(void){
	// Your code here!
	Test01();
	Test02();
}

void main_2(void) {
#if NUM == 0
      a=1;
#elif NUM == -1
      a=2;
#else
      a=3;
#endif
}
 
void Test01(void)
{
	printf("test01\r\n");
}
 
_EXT void Test02(void)
{
			  do{
							while(1) {
								printf("test02\r\n");
							}
			  }while(1)
}
 
static BOOL_T Test03(E_CMD_SEQ *p_seq)
{
			  UINT32_T len;
			  INT32_T lRet;
			  BOOL_T bRet = BOOL_FALSE;
			  common_frame_t			 msg;
			 
			  lRet = LOSW_MsgRecieve(DUMMY_MSG, (void **)&msg);
			  if(lRet > 0){
							switch(msg.id){
										  case CMD_1:
														if(CMD_SEQ_1 == *p_seq){
														}else{
															a=1;
														}
														break;
										  case CMD_2:
#ifdef DUMMY_LOCK
														if(true == dummy1){
																	  debug_print("[dummp] Send Lock Through.");
														}else if(CMD_TEST == *p_seq){
#else
													if(CMD_TEST == *p_seq){
														A = 1;
														B = 1;
#endif
																	  sta_flg = BOOL_FALSE;
														}else{
																	  debug_print_dw1("[dump] Send Error:", (UINT32_T)*p_seq);
														}
														break;
										  default:
														debug_print_dw1("dummySnd ID Error!:", (UINT32_T)msg.id);
														break;
							}
			  }else if(E_TMOUT == lRet){
							dummy = CMD_WAIT;
							bRet = BOOL_TRUE;
			  }else{
							bRet = BOOL_FALSE;
			  }
			 
			  return bRet;
}

void Test04(){
// A
// B
// C
#ifdef AAA
	#ifdef BBB
		x=b;
	#else
		x=c;
	#endif
#else
	x=a;
#endif


#ifdef CCC
	x=0;
#endif
	aaa=1;
}
	

void sub_def_samples(){
	#ifndef MACRO_H
		#define MACRO_H

		#define SWAP(type, a, b) \
		        do {type tmp = a; a = b; b = tmp;} while (0)

		#define XOR_SWAP(a, b) \
		        do {a ^= b; b ^= a; a ^= b;} while (0)


		#define MAX(a, b) ((a) > (b) ? (a) : (b))
	#else
		#define MIN(a, b) ((a) < (b) ? (a) : (b))
	#endif
}

void def_zero_sample(){
	x=1;
	y=1;
	
#ifdef 0
	x=0;
#endif

#ifdef AAA
	#ifdef BBB
		x=b;
	#else
		x=c;
	#endif
#else
	x=a;
#endif
	
}


void if_zero_one_sample(void) {
    int i=0;
#if 0
    printf("#IF ZERO\n"); /* デバッグ用(#if 0) */
	#ifdef AAA
		#ifdef BBB
			x=b;
		#else
			x=c;
		#endif
	#else
		x=a;
	#endif
#endif
#if 1
    printf("#IF ONE\n"); /* デバッグ用(#if 0)*/
	#ifdef AAA
		#ifdef BBB
			x=d;
		#else
			x=e;
		#endif
	#else
		x=f;
	#endif
#endif
    printf("x = %d\n", x);
}


#
int elif_sample(void)
{
#ifdef AAA	
	#if PROGRAM_MODE == 0
	    puts("RESULT 1-1");
	#elif PROGRAM_MODE == 1
	    puts("RESULT 1-2");
	#else
	    puts("RESULT 1-3");
	#endif
#else
	#if PROGRAM_MODE == 0
	    puts("RESULT 2-1");
	#elif PROGRAM_MODE == 1
	    puts("RESULT 2-2");
	#else
	    puts("RESULT 2-3");
	#endif
#endif

}

void sub_def_samples2(){
	#if DLEVEL > 5
	    #if STACKUSE == 1
	abc = 1;
	    #else
	abc = 2;
	    #endif
	#else
	    #if ((STACKUSE == 1) | (ABCEFGHI == 1))
	abc = 3;
	    #else
	abc = 4;
	    #endif
	#endif
	#if DLEVEL == 0
	abc = 5;
	#elif DLEVEL == 1
	abc = 6;
	#elif DLEVEL > 5
	abc = 7;
	#else
	abc = 8;
	#endif
}